import React from 'react'
export const Footer = () => {
  return (
    <div className='footerdemo'>
        <h1 style={{textAlign:'center'}}>
            Company Name @copyright 2022
        </h1>
    </div>
  )
}
