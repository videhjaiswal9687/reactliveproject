/*
Function Component (StateLess Component)
*/

function HeaderDemo() {
    return (
        <div style={{position:'fixed',top:0,width:'100%',backgroundColor:'brown',color:'white'}}>
        <h1 style={{textAlign:'center'}}>
        Welcome to React JS Sessions!!!
        </h1>
    </div>
    )
}

export default HeaderDemo;