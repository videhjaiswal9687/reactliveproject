import React, { Component } from 'react'

export default class Email extends Component {
    render() {
        return (
            <div style={{ backgroundColor: 'darkgoldenrod', color: 'white' }}>
                <h1>Email</h1>
            </div>
        )
    }
}
