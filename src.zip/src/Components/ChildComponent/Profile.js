import React, { Component } from 'react'

export default class Profile extends Component {
    render() {
        return (
            <div style={{ backgroundColor: 'red', color: 'white' }}>
                <h1>Profile</h1>
            </div>
        )
    }
}
